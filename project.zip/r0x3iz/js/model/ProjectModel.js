/**
 * FavoriteDao
 * @flow
 */
'use strict';

export default function ProjectModel(item,isFavorite){
  this.item=item;
  this.isFavorite=isFavorite;
}
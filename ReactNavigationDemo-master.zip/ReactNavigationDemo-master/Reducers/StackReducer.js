// import { MyApp } from '../Test/Routers';
//
// export default function StackReducer(state , action) {
//     let nextState;
//     switch (action.type) {
//         default:
//             // console.log(state);
//             // console.log(action);
//             nextState = MyApp.router.getStateForAction(action, state);
//             break;
//     }
//     return nextState || state;
// }


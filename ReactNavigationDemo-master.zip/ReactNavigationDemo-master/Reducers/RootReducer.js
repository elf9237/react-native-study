// import { combineReducers } from 'redux';
// import nav from './StackReducer';
//
// //取决于这里你加入了多少 reducer
// export default RootReducer = combineReducers({
//     nav
// });
